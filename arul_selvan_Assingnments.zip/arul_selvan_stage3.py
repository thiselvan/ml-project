user_input=input()
name = user_input.split(',')[0]
marks_1= int(user_input.split(',')[1])
marks_2= int(user_input.split(',')[2])
marks_3= int(user_input.split(',')[3])

total = marks_1+marks_2+marks_3
percentage = (total/300)*100 

print("Total : "+str(total)+"/300")
print("Percentage : {} %".format(percentage))

if percentage >= 75:
    print("Grade : A")
elif percentage >= 60:
    print("Grade : B")
elif percentage >= 40:
    print("Grade : C")
elif percentage < 40:
    print("Grade : F")