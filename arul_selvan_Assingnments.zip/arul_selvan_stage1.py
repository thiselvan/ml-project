'''
Docstring for stage_1
Stage 1: Basic Calculator
Create a calculator that takes two numbers and an operator (+, -, *, /) and shows the result.

Constraints:

Handle division by zero
Use if-elif-else statements
Example:

Input: 10, 5, +
Output: Result = 15
'''
user_input= input()
number_1 = int(user_input.split(',')[0])
number_2 = int(user_input.split(',')[1])
operator = user_input.split(',')[2]

if operator == '+':
    result = number_1+number_2
elif operator == '-':
    result = number_1-number_2
elif operator == '*':
    result = number_1*number_2
elif operator == '/':
    result = number_1/number_2

print("Result = ",result)